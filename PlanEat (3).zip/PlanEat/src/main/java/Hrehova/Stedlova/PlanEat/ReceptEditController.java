package Hrehova.Stedlova.PlanEat;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.converter.NumberStringConverter;

public class ReceptEditController {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private TextField textFieldNazovReceptu;

	@FXML
	private TextField textFieldPocetPorcii;

	@FXML
	private TextField textFieldCas;

	@FXML
	private TextArea textAreaPostup;

	@FXML
	private CheckBox checkBoxOblubeny;

	@FXML
	private TableView<Ingrediencia> tableViewIngrediencie;

	@FXML
	private TableColumn<Ingrediencia, String> stlpecNazov;
	
	@FXML
	private ComboBox<Ingrediencia> comboBoxIngrediencie;
	
    @FXML
    private TextField textFieldMnozstvo;
	@FXML
	private Button buttonPridatIngredienciu;
	@FXML
	private Button buttonPridat;

	@FXML
	private TableColumn<Ingrediencia, String> stlpecMnozsvo;

	@FXML
	private TableColumn<Ingrediencia, String> stlpecAlergen;

	@FXML
	private ImageView imageViewRecept;
	@FXML
	private Button buttonUlozit;

	private ReceptFxModel model = new ReceptFxModel();
	private IngrediencieDao ingrediencieDao = DaoFactory.INSTANCE.getIngrediencieDao();
	private ObservableList<Ingrediencia> ingrediencieList;
	private Map<Ingrediencia, String> ingrediencie_mnozstvo = new HashMap<Ingrediencia, String>();

	public ReceptEditController() {	
	}
	
	public ReceptEditController(Recept recept) {
		model.setRecept(recept);
	}
	
	@FXML
	void actionPridat(ActionEvent event) {
		Ingrediencia ingrediencia = comboBoxIngrediencie.getSelectionModel().getSelectedItem();
		ingrediencia.setMnozstvo(textFieldMnozstvo.getText());
		
		
		ingrediencie_mnozstvo.put(ingrediencia, textFieldMnozstvo.getText());	
		tableViewIngrediencie.getItems().add(ingrediencia);
		
	}
   

	@FXML
	void actionPridatIngrediencie(ActionEvent event) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Ingrediencie.fxml"));

			Parent parent = fxmlLoader.load();
			Stage stage = new Stage();
			stage.setTitle("Ingrediencie");
			stage.setScene(new Scene(parent));
			stage.showAndWait();
			ingrediencieList = FXCollections.observableArrayList(ingrediencieDao.getAll());
			comboBoxIngrediencie.setItems(ingrediencieList);

		} catch (IOException e) {

			e.printStackTrace();
		}
	}



    @FXML
    void actionOdstranIngredienciu(ActionEvent event) {
    	tableViewIngrediencie.getItems().removeAll(tableViewIngrediencie.getSelectionModel().getSelectedItem());
    }
    
	@FXML
	void actionUlozit(ActionEvent event) {
		model.getIngrediencie().clear();
		List<Ingrediencia> ingrediencie = tableViewIngrediencie.getItems();	
		model.setIngrediencie(ingrediencie);
		
		model.setIngrediencie_mnozstvo(ingrediencie_mnozstvo);
		

		DaoFactory.INSTANCE.getReceptyDao().update(model.getRecept());

		Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
		stage.close();
	}

	@FXML
	void initialize() {
		ingrediencieList = FXCollections.observableArrayList(ingrediencieDao.getAll());
		comboBoxIngrediencie.setItems(ingrediencieList);
		
		textFieldNazovReceptu.textProperty().bindBidirectional(model.nazovReceptuProperty());
		textFieldCas.textProperty().bindBidirectional(model.casPripravyProperty());
		textFieldPocetPorcii.textProperty().bindBidirectional(model.pocetPorciiProperty(), new NumberStringConverter());
		textAreaPostup.textProperty().bindBidirectional(model.postupProperty());
		checkBoxOblubeny.selectedProperty().bindBidirectional(model.oblubenyProperty());
		tableViewIngrediencie.setItems(FXCollections.observableArrayList(model.getIngrediencie()));
		
		
		for (Ingrediencia i : model.getIngrediencie()) {
			i.setMnozstvo(model.getIngrediencie_mnozstvo().get(i));		
		}
		
		stlpecNazov.setCellValueFactory(new PropertyValueFactory<>("nazov_ingrediencie"));
		stlpecMnozsvo.setCellValueFactory(new PropertyValueFactory<>("mnozstvo"));
		stlpecAlergen.setCellValueFactory(new PropertyValueFactory<>("alergen"));
		
		for(Ingrediencia i:tableViewIngrediencie.getItems()) {	
			ingrediencie_mnozstvo.put(i, stlpecMnozsvo.getCellData(i));
		}
	}
}
