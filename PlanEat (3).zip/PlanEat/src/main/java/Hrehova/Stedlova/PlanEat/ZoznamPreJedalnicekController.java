package Hrehova.Stedlova.PlanEat;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class ZoznamPreJedalnicekController {

	  @FXML 
	    private ListView<Recept> listViewRecepty; 

	    @FXML 
	    private Button buttonPridatDoJedalnicku; 
	    
	    private ReceptyDao receptyDao = DaoFactory.INSTANCE.getReceptyDao();

	    @FXML
	    void buttonPridatDoJedalnicku(ActionEvent event) {
	    	Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
			stage.close();
	    }
		public Recept getRecept() {
			Recept recept = new Recept();
			recept = listViewRecepty.getSelectionModel().getSelectedItem();
			return recept;
		}

	    @FXML 
	    void initialize() {
	    	listViewRecepty.setItems(FXCollections.observableArrayList(receptyDao.getAll()));
	       
	    }
}
