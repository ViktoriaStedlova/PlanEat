package Hrehova.Stedlova.PlanEat;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.converter.NumberStringConverter;

public class ReceptEditController {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private TextField textFieldNazovReceptu;

	@FXML
	private TextField textFieldPocetPorcii;

	@FXML
	private TextField textFieldCas;

	@FXML
	private TextArea textAreaPostup;

	@FXML
	private CheckBox checkBoxOblubeny;

	@FXML
	private TableView<Ingrediencia> tableViewIngrediencie;

	@FXML
	private TableColumn<Ingrediencia, String> stlpecNazov;

	@FXML
	private TableColumn<Ingrediencia, String> stlpecMnozsvo;

	@FXML
	private TableColumn<Ingrediencia, String> stlpecAlergen;

	@FXML
	private ImageView imageViewRecept;
	@FXML
	private Button buttonUlozit;

	private ReceptFxModel model = new ReceptFxModel();

	public ReceptEditController(Recept recept) {
		model.setRecept(recept);

	}

    @FXML
    void actionOdstranIngredienciu(ActionEvent event) {
    	tableViewIngrediencie.getItems().removeAll(tableViewIngrediencie.getSelectionModel().getSelectedItem());
    }
    
	@FXML
	void actionUlozit(ActionEvent event) {
		model.getIngrediencie().clear();
		List<Ingrediencia> ingrediencie = tableViewIngrediencie.getItems();	
		model.setIngrediencie(ingrediencie);
		
		DaoFactory.INSTANCE.getReceptyDao().save(model.getRecept());

		Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
		stage.close();
	}

	@FXML
	void initialize() {
		textFieldNazovReceptu.textProperty().bindBidirectional(model.nazovReceptuProperty());
		textFieldCas.textProperty().bindBidirectional(model.casPripravyProperty());
		textFieldPocetPorcii.textProperty().bindBidirectional(model.pocetPorciiProperty(), new NumberStringConverter());
		textAreaPostup.textProperty().bindBidirectional(model.postupProperty());
		checkBoxOblubeny.selectedProperty().bindBidirectional(model.oblubenyProperty());
		tableViewIngrediencie.setItems(FXCollections.observableArrayList(model.getIngrediencie()));

		for (Ingrediencia i : model.getIngrediencie()) {
			i.setMnozstvo(model.getIngrediencie_mnozstvo().get(i));
		}

		stlpecNazov.setCellValueFactory(new PropertyValueFactory<>("nazov_ingrediencie"));
		stlpecMnozsvo.setCellValueFactory(new PropertyValueFactory<>("mnozstvo"));
		stlpecAlergen.setCellValueFactory(new PropertyValueFactory<>("alergen"));

	}
}
