package Hrehova.Stedlova.PlanEat;


import java.io.IOException;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class JedalnicekController {

	@FXML
	private TableView<Jedalnicek> tableViewJedalnicek;

	@FXML
	private TableColumn<Jedalnicek, String> denStlpec;

	@FXML
	private TableColumn<Jedalnicek, String> nazovStlpec;

	@FXML
	private TableColumn<Jedalnicek, LocalDate> datumStlpec;

	@FXML
	private TextField textFieldNazov;

	@FXML
	private TextField textFieldDen;

	@FXML
	private DatePicker datePickerDatum;

	@FXML
	private Button buttonUloz;

	@FXML
	private Button buttonVybratRecept;

	private JedalnicekDao jedalnicekDao = DaoFactory.INSTANCE.getJedalnicekDao();


	private ReceptFxModel receptFxModel = new ReceptFxModel();


	   @FXML
	    void actionDatum(ActionEvent event) {
		   textFieldDen.setText(datePickerDatum.getValue().getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault()));
	    }

	@FXML
	void actionUlozit(ActionEvent event) {
		Jedalnicek jedalnicek = new Jedalnicek();
			
		jedalnicek.setDatum(datePickerDatum.getValue());
		
		jedalnicek.setDen(textFieldDen.getText());
		
		jedalnicek.setRecept(receptFxModel.getRecept());
		jedalnicek.setNazovReceptu(receptFxModel.getRecept().getNazov_receptu());
		
		jedalnicekDao.pridaj(jedalnicek);
		tableViewJedalnicek.setItems(FXCollections.observableArrayList(jedalnicekDao.getAll()));
		
	}

	@FXML
	void actionVybratRecept(ActionEvent event) {

		try {
			ZoznamReceptovController zrc = new ZoznamReceptovController();

			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ZoznamReceptov.fxml"));
			fxmlLoader.setController(zrc);
			Parent parent = fxmlLoader.load();
			Stage stage = new Stage();
			stage.setTitle("ZoznamReceptov");
			stage.setScene(new Scene(parent));

			stage.showAndWait();
			
			receptFxModel.setRecept(zrc.getRecept());
			textFieldNazov.setText(receptFxModel.getNazovReceptu());
			

		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	@FXML
	void initialize() {
		tableViewJedalnicek.setItems(FXCollections.observableArrayList(jedalnicekDao.getAll()));
		datePickerDatum.setValue(LocalDate.now());
		textFieldDen.setText(datePickerDatum.getValue().getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault()));
		textFieldDen.setEditable(false);
		
		denStlpec.setCellValueFactory(new PropertyValueFactory<>("den"));
		nazovStlpec.setCellValueFactory(new PropertyValueFactory<>("nazovReceptu"));
		datumStlpec.setCellValueFactory(new PropertyValueFactory<>("datum"));
		


	}

}